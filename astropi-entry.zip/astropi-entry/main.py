import numpy as np
import datetime as dt
import pandas as pd
from logzero import logger,logfile
from orbit import ISS
from skyfield.api import load
from sense_hat import SenseHat
import time

logfile("data/logfile.log")
sense = SenseHat()

w = (255,255,255)
b = (0,0,0)
hourglass = [
    w,w,w,w,w,w,w,w,
    b,w,b,b,b,b,w,b,
    b,b,w,b,b,w,b,b,
    b,b,b,w,w,b,b,b,
    b,b,b,w,w,b,b,b,
    b,b,w,b,b,w,b,b,
    b,w,b,b,b,b,w,b,
    w,w,w,w,w,w,w,w 
]

sense.set_pixels(hourglass)

#calculate how much each angle changed
def moved(x0:float,y0:float,z0:float,x1:float,y1:float,z1:float):
    nx,ny,nz = (x1-x0,y1-y0,z1-z0)
    return nx,ny,nz

#convert roll pitch yaw to a rotation matrix
#x: roll
#y: pitch
#z: yaw
#returns a 3x3 numpy matrix
def rotmatrix(x: float, y: float, z: float):
    Rx = np.array([[1,0,0],[0,np.cos(x),-np.sin(x)],[0,np.sin(x),np.cos(x)]])
    Ry = np.array([[np.cos(y),0,np.sin(y)],[0,1,0],[-np.sin(y),0,np.cos(y)]])
    Rz = np.array([[np.cos(z),-np.sin(z),0],[np.sin(z),np.cos(z),0],[0,0,1]])
    rotmat=np.matmul(np.matmul(Rz,Ry),Rx)
    return rotmat

#finds axis and angle of rotation given a 3x3 rotation matrix
def findaxisangle(rotmat:np.array):
    #eigenvalues and eignevectors
    rotmateig = np.linalg.eig(rotmat)

    #find which eignevalue is real
    #at least one will be, so j will be defined after this loop
    for i in range(len(rotmateig[0])): #for each eigenvalue
        if np.isreal(rotmateig[0][i]):
            j=i
            break

    rotmateigvec = rotmateig[1]  #matrix of eigenvectors
    rotax = rotmateigvec[:,j] #this is the rotation axis - it corresponds to a real eignevalue=1
    rotax = rotax.real #removes complex part (which would be 0*j)

    v = rotmateig[0][j-1] #takes one of the other eigen values, which will be complex unlex rotmat is identity
    a = np.real(v)
    b = np.imag(v)

    rotan = np.arctan2(b,a)#complex eignevalues will have the form cos(phi) + i sin(phi) so take the arctan2(sin,cos)
    
    return rotax,rotan


#initialize the variables
tstart = dt.datetime.now() #start time
N = 5  #n of readings to take
i=0 #counter of readings
saveN = 1  #n of readings to save in single save file
tdelta = dt.timedelta(minutes=180) #how much time to run program for
tend = tstart+tdelta #finish time for program

data = pd.DataFrame({"ts": np.full(saveN,np.nan), 
                     "roll": np.full(saveN,np.nan),
                     "pitch": np.full(saveN,np.nan),
                     "yaw": np.full(saveN,np.nan),
                     "axisX":np.full(saveN,np.nan),        #reserve space for data storage
                     "axisY":np.full(saveN,np.nan),
                     "axisZ":np.full(saveN,np.nan),
                     "angle":np.full(saveN,np.nan),
                     "elevation":np.full(saveN,np.nan)
                     })

try:
    o = sense.get_orientation_radians() #take sensor reading
except Exception as e:
    logger.error(f'{e.__class__.__name__}: {e}')
    o = (0.,0.,0.)
oldroll,oldpitch,oldyaw=o["roll"], o["pitch"], o["yaw"]
done = False
tnow = dt.datetime.now()

logger.info("entering loop...")
while not done:
    try:
        o = sense.get_orientation_radians() #take sensor reading
        roll,pitch,yaw=o["roll"], o["pitch"], o["yaw"]
        try:
            phi,theta,psi=moved(roll,pitch,yaw,oldroll,oldpitch,oldyaw)
            ax, an = findaxisangle(rotmatrix(phi,theta,psi))
        except Exception as e:
            logger.error(f'{e.__class__.__name__}: {e}\nstep {i}')
            ax = np.full(3,np.nan)
            an = np.nan
        try:
            location = ISS.coordinates()
            elevation = location.elevation.km #recieve elevation
        except Exception as e:
            logger.error(f'{e.__class__.__name__}: {e}\nstep {i}')
            elevation = np.nan

        data.loc[i%saveN,:] = [tnow,roll,pitch,yaw,ax[0],ax[1],ax[2],an,elevation] #put data into dataframe
        oldroll,oldpitch,oldyaw = roll,pitch,yaw #save old roll pitch yaw for next step

        if (i+1)%saveN==0: #if time to save file 
            try:
                filename = "data/readings{:03d}.zip".format((i+1)//saveN) #save file label
                data.to_pickle(filename)
                data = pd.DataFrame({"ts": np.full(saveN,np.nan), 
                        "roll": np.full(saveN,np.nan),
                        "pitch": np.full(saveN,np.nan),
                        "yaw": np.full(saveN,np.nan),
                        "axisX":np.full(saveN,np.nan),        #reserve space for data storage
                        "axisY":np.full(saveN,np.nan),
                        "axisZ":np.full(saveN,np.nan),
                        "angle":np.full(saveN,np.nan),
                        "elevation":np.full(saveN,np.nan)
                        })
                logger.info(f"saved file {filename}")
                time.sleep(0.3)
            except Exception as e:
                logger.error(f'{e.__class__.__name__}: {e}\nstep {i}')
                time.sleep(0.3)
        else:
            time.sleep(0.5)


    except Exception as e:
        logger.error(f'{e.__class__.__name__}: {e}\nstep {i}')
        
    tnow = dt.datetime.now()
    i+=1
    done = (tnow>=tend) or (i>=N) #loop exit condition

if i<N: #if exit was due to time
    data.to_pickle("data/readings{:03d}.zip".format((i//saveN)+1)) #save last readings
    logger.info("saved file data/readings{:03d}.zip".format((i//saveN)+1))

logger.info("done.")
sense.show_message("done.")
sense.clear()